import { startTransition, useEffect, useState } from "react";
import {
  featureCards,
  impactItems,
  languageOptions,
  learningModules,
  notices,
  services,
  translations
} from "./content.js";

const stats = [
  { number: "12+", key: "statOne" },
  { number: "3", key: "statTwo" },
  { number: "24/7", key: "statThree" }
];

function App() {
  const [language, setLanguage] = useState("en");
  const [fontSize, setFontSize] = useState(16);
  const [isHighContrast, setIsHighContrast] = useState(false);
  const [filter, setFilter] = useState("all");
  const [expandedServices, setExpandedServices] = useState({});

  const copy = translations[language];
  const visibleServices = services[language].filter(
    (service) => filter === "all" || service.category === filter
  );

  useEffect(() => {
    document.documentElement.lang = language === "en" ? "en" : "hi";
  }, [language]);

  useEffect(() => {
    document.documentElement.style.setProperty("--font-size-base", `${fontSize}px`);
  }, [fontSize]);

  useEffect(() => {
    document.body.classList.toggle("high-contrast", isHighContrast);
    return () => document.body.classList.remove("high-contrast");
  }, [isHighContrast]);

  function handleLanguageChange(event) {
    const nextLanguage = event.target.value;
    startTransition(() => setLanguage(nextLanguage));
  }

  function updateFilter(event) {
    const nextValue = event.target.value;
    startTransition(() => setFilter(nextValue));
  }

  function readSummary() {
    if (!("speechSynthesis" in window)) {
      window.alert("Text-to-speech is not supported in this browser.");
      return;
    }

    const utterance = new SpeechSynthesisUtterance(copy.heroText);
    utterance.lang =
      languageOptions.find((option) => option.value === language)?.speechLang ?? "en-IN";
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  }

  function toggleServiceDetails(title) {
    startTransition(() => {
      setExpandedServices((current) => ({
        ...current,
        [title]: !current[title]
      }));
    });
  }

  return (
    <>
      <a className="skip-link" href="#main-content">
        Skip to content
      </a>

      <header className="site-header">
        <div className="brand-block">
          <div className="brand-badge">{copy.brandBadge}</div>
          <h1>JanConnect</h1>
          <p className="brand-copy">{copy.brandCopy}</p>
        </div>

        <div className="access-panel" aria-label="Accessibility controls">
          <label className="language-picker" htmlFor="language-select">
            <span>{copy.languageLabel}</span>
            <select
              id="language-select"
              className="language-select"
              value={language}
              onChange={handleLanguageChange}
            >
              {languageOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </label>
          <button
            className="control-button"
            type="button"
            onClick={() => setFontSize((size) => Math.min(22, size + 1))}
          >
            A+
          </button>
          <button
            className="control-button"
            type="button"
            onClick={() => setFontSize((size) => Math.max(14, size - 1))}
          >
            A-
          </button>
          <button
            className="control-button"
            type="button"
            onClick={() => setIsHighContrast((value) => !value)}
          >
            {copy.highContrast}
          </button>
          <button className="control-button primary" type="button" onClick={readSummary}>
            {copy.readSummary}
          </button>
        </div>
      </header>

      <main id="main-content">
        <section className="hero-section">
          <div className="hero-copy">
            <p className="eyebrow">{copy.eyebrow}</p>
            <h2>{copy.heroTitle}</h2>
            <p className="hero-text">{copy.heroText}</p>

            <div className="hero-actions">
              <a className="cta-button" href="#services">
                {copy.exploreServices}
              </a>
              <a className="ghost-button" href="#impact">
                {copy.seeImpact}
              </a>
            </div>
          </div>

          <aside className="hero-card" aria-label="Platform highlights">
            {stats.map((stat) => (
              <div className="stat-row" key={stat.key}>
                <span className="stat-number">{stat.number}</span>
                <span className="stat-label">{copy[stat.key]}</span>
              </div>
            ))}
          </aside>
        </section>

        <section className="feature-grid" aria-label="Key features">
          {featureCards[language].map((feature) => (
            <article className="feature-card" key={feature.title}>
              <h3>{feature.title}</h3>
              <p>{feature.text}</p>
            </article>
          ))}
        </section>

        <section id="services" className="services-section">
          <div className="section-heading">
            <p className="eyebrow">{copy.serviceEyebrow}</p>
            <h2>{copy.serviceTitle}</h2>
          </div>

          <div className="service-toolbar">
            <label htmlFor="service-filter">{copy.filterLabel}</label>
            <select id="service-filter" value={filter} onChange={updateFilter}>
              <option value="all">{copy.all}</option>
              <option value="education">{copy.education}</option>
              <option value="governance">{copy.governance}</option>
              <option value="health">{copy.health}</option>
              <option value="community">{copy.community}</option>
            </select>
          </div>

          <div className="service-list">
            {visibleServices.map((service) => (
              <article className="service-card" key={service.title}>
                <span className="pill">{service.pill}</span>
                <h3>{service.title}</h3>
                <p>{service.text}</p>
                <div className="service-actions">
                  <button
                    className="resource-link resource-button"
                    type="button"
                    onClick={() => toggleServiceDetails(service.title)}
                  >
                    {expandedServices[service.title]
                      ? language === "en"
                        ? "Hide Details"
                        : "विवरण छिपाएं"
                      : language === "en"
                        ? "View Details"
                        : "विवरण देखें"}
                  </button>
                  {service.primaryAction ? (
                    <a
                      className="resource-link resource-link-primary"
                      href={service.primaryAction.href}
                      target="_blank"
                      rel="noreferrer"
                    >
                      {service.primaryAction.label}
                    </a>
                  ) : null}
                  {service.secondaryAction ? (
                    <a
                      className="resource-link"
                      href={service.secondaryAction.href}
                      target="_blank"
                      rel="noreferrer"
                    >
                      {service.secondaryAction.label}
                    </a>
                  ) : null}
                </div>

                {expandedServices[service.title] ? (
                  <div className="service-expanded">
                    {service.eligibilityTitle ? (
                      <div className="detail-section">
                        <h4>{service.eligibilityTitle}</h4>
                        <ul className="detail-list">
                          {service.eligibility.map((item) => (
                            <li key={item}>{item}</li>
                          ))}
                        </ul>
                      </div>
                    ) : null}

                    {service.details ? (
                      <div className="detail-section">
                        <h4>{language === "en" ? "Named Resources" : "नामित संसाधन"}</h4>
                        <ul className="detail-list">
                          {service.details.map((detail) => (
                            <li key={detail}>{detail}</li>
                          ))}
                        </ul>
                      </div>
                    ) : null}

                    {service.links ? (
                      <div className="resource-links">
                        {service.links.map((link) => (
                          <a
                            key={link.href}
                            className="resource-link"
                            href={link.href}
                            target="_blank"
                            rel="noreferrer"
                          >
                            {link.label}
                          </a>
                        ))}
                      </div>
                    ) : null}
                  </div>
                ) : null}
              </article>
            ))}
          </div>
        </section>

        <section className="learning-section">
          <div className="section-heading">
            <p className="eyebrow">{copy.learningEyebrow}</p>
            <h2>{copy.learningTitle}</h2>
          </div>

          <div className="module-grid">
            {learningModules[language].map((module) => (
              <article className="module-card" key={module.title}>
                <h3>{module.title}</h3>
                <p>{module.text}</p>
              </article>
            ))}
          </div>
        </section>

        <section id="impact" className="impact-section">
          <div className="section-heading">
            <p className="eyebrow">{copy.impactEyebrow}</p>
            <h2>{copy.impactTitle}</h2>
          </div>

          <div className="impact-list">
            {impactItems[language].map((item) => (
              <div className="impact-item" key={item.title}>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="community-section">
          <div className="section-heading">
            <p className="eyebrow">{copy.communityEyebrow}</p>
            <h2>{copy.communityTitle}</h2>
          </div>

          <div className="notice-board" role="list" aria-label="Community notice board">
            {notices[language].map((notice) => (
              <article className="notice-card" role="listitem" key={notice.title}>
                <p className="notice-tag">{notice.tag}</p>
                <h3>{notice.title}</h3>
                <p>{notice.text}</p>
                {notice.details ? (
                  <ul className="detail-list">
                    {notice.details.map((detail) => (
                      <li key={detail}>{detail}</li>
                    ))}
                  </ul>
                ) : null}
              </article>
            ))}
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <p>{copy.footerText}</p>
      </footer>
    </>
  );
}

export default App;
